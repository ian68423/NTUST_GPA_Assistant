chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchGPA") {
    // 優先使用課程直接頁面，這類頁面在 Body_2.txt 中顯示包含 GPA 資訊 [cite: 106, 138]
    const url = `https://myntust.com/courses/${request.code}`;

    fetch(url, {
      method: 'GET',
      credentials: 'include', // 重點：強制帶上瀏覽器已有的 Cookie 與驗證狀態
      headers: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'User-Agent': navigator.userAgent, // 使用與當前瀏覽器完全一致的 User-Agent
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Upgrade-Insecure-Requests': '1'
      }
    })
      .then(response => response.text())
      .then(html => {
        // 檢查是否仍拿到 Cloudflare 的挑戰頁面腳本 [cite: 153, 154]
        if (html.includes("rocket-loader.min.js") || html.includes("challenge-platform")) {
            throw new Error("請在新開啟的 myNTUST 分頁中隨便搜尋一門課來啟動驗證");
        }

        // 解析模式：尋找 Body_2.txt 中出現的 GPA 數值標籤結構 [cite: 106, 125]
        // 根據來源，GPA 通常位於 text-emerald-600 類別的 div 中 [cite: 106, 111]
        const gpaMatch = html.match(/>([\d\.]+)\s*<\/div>[^>]*>\s*GPA\s*<\/div>/);
        
        if (gpaMatch) {
            sendResponse({ success: true, gpa: gpaMatch[1] });
        } else {
            // 嘗試解析 data-page JSON 結構 [cite: 1]
            const dataPageMatch = html.match(/data-page=(['"])(.*?)\1/);
            if (dataPageMatch) {
                const data = JSON.parse(dataPageMatch[2].replace(/&quot;/g, '"'));
                const gpa = data.props.course?.gpa || data.props.courses?.data?.[0]?.gpa;
                if (gpa) {
                    sendResponse({ success: true, gpa: gpa });
                    return;
                }
            }
            throw new Error("網頁已載入，但找不到 GPA 數值");
        }
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    
    return true; 
  }
});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes("myntust.com")) {
    
    // 狀況 1：如果背景分頁被踢回登入頁
    if (tab.url.includes("/login")) {
      console.log("「GPA助手」：偵測到登入需求，在背景執行自動登入...");
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["autologin.js"]
      });
    } 
    
    // 狀況 2：登入完成後回到首頁，執行「二次跳轉」去抓資料
    else if (tab.url === "https://myntust.com/" || tab.url === "https://myntust.com") {
      chrome.storage.local.get(['pendingCourse', 'fastSearch'], (res) => {
        if (res.pendingCourse) {
          console.log("「GPA助手」：登入成功，自動導向課程頁...");
          chrome.tabs.update(tabId, { url: `https://myntust.com/courses/${res.pendingCourse}` });
          // 注意：這裡不刪除 pendingCourse，留給擷取腳本完成後再刪除
        }
      });
    }
  }
});

// 監聽來自 content.js 的開啟請求 (背景模式)
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.action === "openBackgroundSearch") {
    chrome.tabs.create({
      url: message.url,
      active: false // 關鍵：不干擾使用者目前的視覺
    });
  }
});