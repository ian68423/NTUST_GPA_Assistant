/**
 * 載入已儲存的設定
 */
document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(['email', 'pw', 'fastSearch'], (data) => {
    if (data.email) {
      document.getElementById('email').value = data.email;
    }
    if (data.pw) {
      document.getElementById('pw').value = data.pw;
    }
    // 設定開關狀態，預設為關閉 (false)
    document.getElementById('fastSearch').checked = !!data.fastSearch;
  });
});

/**
 * 儲存設定至本地空間
 */
document.getElementById('save').onclick = () => {
  const email = document.getElementById('email').value.trim();
  const pw = document.getElementById('pw').value;
  const fastSearch = document.getElementById('fastSearch').checked;

  if (!email || !pw) {
    const msg = document.getElementById('msg');
    msg.style.color = "#f44336";
    msg.innerText = '請完整填寫帳號與密碼';
    return;
  }

  // 執行儲存
  chrome.storage.local.set({
    email: email,
    pw: pw,
    fastSearch: fastSearch
  }, () => {
    console.log("「GPA助手」：設定儲存成功。");
    const msg = document.getElementById('msg');
    msg.style.color = "#4CAF50";
    msg.innerText = '設定儲存成功！';

    // 儲存後一秒自動關閉小視窗
    setTimeout(() => {
      window.close();
    }, 1000);
  });
};