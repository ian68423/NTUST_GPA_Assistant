(function() {
  // 防止重複注入
  if (window.gpaCaptureInjected) return;
  window.gpaCaptureInjected = true;

  console.log("「GPA助手」：擷取與自動關閉腳本已啟動。");

  // 從 URL 取得課號 (URL 格式通常為 .../courses/GE3904301)
  const courseCode = window.location.pathname.split('/').pop();
  let hasProcessed = false;

  /**
   * 儲存結果並決定是否關閉分頁
   * @param {string} val GPA數值 或 "無資訊"
   */
  const finishTask = (val) => {
    if (hasProcessed) return;
    hasProcessed = true;

    chrome.storage.local.get(['gpa_cache', 'fastSearch'], (res) => {
      const cache = res.gpa_cache || {};
      cache[courseCode] = val;
      
      // 更新快取並清除待處理標記
      chrome.storage.local.set({ 
        gpa_cache: cache, 
        pendingCourse: null 
      }, () => {
        console.log(`「GPA助手」：課號 ${courseCode} 紀錄為 [${val}]`);
        
        // 如果開啟「快速查詢」模式，儲存完畢後立刻關閉分頁
        if (res.fastSearch) {
          console.log("「GPA助手」：快速查詢模式，正在自動關閉分頁...");
          window.close();
        }
      });
    });
  };

  /**
   * 嘗試從網頁 DOM 中尋找 GPA 數值
   */
  const captureData = () => {
    // 1. 尋找 GPA 數值標籤
    const divs = Array.from(document.querySelectorAll('div'));
    for (let el of divs) {
      // 尋找內容剛好為 "GPA" 的 div
      if (el.innerText.trim() === 'GPA') {
        // 根據 Body_3.txt 結構，數值通常在 GPA 標籤的前一個元素
        const valEl = el.previousElementSibling;
        if (valEl && !isNaN(parseFloat(valEl.innerText))) {
          finishTask(valEl.innerText.trim());
          return true;
        }
      }
    }

    // 2. 尋找「無資訊」的特徵文字
    const pageText = document.body.innerText;
    const noDataKeywords = ["尚未收錄", "未有資料", "查無此課程", "尚無資訊", "—"];
    if (noDataKeywords.some(key => pageText.includes(key))) {
      finishTask("無資訊");
      return true;
    }

    return false;
  };

  // 因為是 SPA 網頁，內容是動態產生的，使用 MutationObserver 持續監測
  const observer = new MutationObserver(() => {
    if (captureData()) {
      observer.disconnect();
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // 初次執行偵測（預防內容已在載入腳本前產生）
  captureData();

  /**
   * 安全超時機制：
   * 如果 4 秒內都沒偵測到數值或無資料字眼，可能是載入失敗或結構改變
   * 強制標記為「無資訊」並結束，避免分頁永遠卡在背景
   */
  setTimeout(() => {
    if (!hasProcessed) {
      console.log("「GPA助手」：擷取超時，自動標記為無資訊。");
      observer.disconnect();
      finishTask("無資訊");
    }
  }, 4000);

  // --- 建立 UI：右下角懸浮關閉按鈕 ---
  // 即使在快速模式下也建立，方便使用者在出錯時手動關閉
  const closeBtn = document.createElement('div');
  closeBtn.id = 'gpa-floating-close-btn';
  closeBtn.innerHTML = `
    <div class="gpa-close-content">
      <span class="gpa-close-icon">✕</span>
      <span class="gpa-close-text">關閉並返回</span>
    </div>
  `;

  closeBtn.onclick = () => {
    window.close();
  };

  document.body.appendChild(closeBtn);

})();