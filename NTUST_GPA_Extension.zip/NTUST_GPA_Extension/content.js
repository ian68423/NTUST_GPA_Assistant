/**
 * 台科大 GPA 查詢助手 - 課程列表注入腳本
 * 負責在選課系統表格中新增按鈕，並顯示快取中的 GPA 資料
 */

const tableObserver = new MutationObserver(() => {
  // 根據 Body.txt，選課系統表格使用 Vuetify 的 v-datatable
  const rows = document.querySelectorAll('table.v-datatable tbody tr');
  
  rows.forEach(row => {
    // 1. 提取課號 (通常在第一欄)
    const codeCell = row.cells[0];
    if (!codeCell) return;
    
    const currentCode = codeCell.innerText.trim();
    // 排除標題列或非課號行
    if (currentCode.length < 5 || currentCode.includes("課程代碼")) return;

    // 2. 取得現有的 GPA 容器 (如果有的話)
    const existingContainer = row.querySelector('.gpa-container');
    
    // --- 核心修正：處理分頁/標籤切換時的組件復用 ---
    // 如果「容器不存在」或是「容器綁定的課號不等於目前這一列的課號」
    if (!existingContainer || existingContainer.getAttribute('data-bound-code') !== currentCode) {
      
      // 如果課號不符（分頁切換了），先移除舊按鈕
      if (existingContainer) {
        existingContainer.remove();
      }

      // 3. 建立 GPA 容器
      const container = document.createElement('div');
      container.className = 'gpa-container';
      container.setAttribute('data-bound-code', currentCode); // 綁定身分證

      // 4. 建立「查詢 GPA」按鈕
      const btn = document.createElement('button');
      btn.innerText = '查詢 GPA';
      btn.className = 'gpa-btn';
      
      btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation(); // 防止觸發選課系統原本的列點擊事件
        
        // 儲存目前要查詢的課號，供後端跳轉使用
        chrome.storage.local.set({ pendingCourse: currentCode }, () => {
          // 檢查使用者設定的查詢模式
          chrome.storage.local.get(['fastSearch'], (res) => {
            if (res.fastSearch) {
              // 快速查詢：通知後台在「背景分頁」開啟，不跳轉焦點
              chrome.runtime.sendMessage({ 
                action: "openBackgroundSearch", 
                url: `https://myntust.com/courses/${currentCode}` 
              });
            } else {
              // 一般查詢：直接開啟新分頁並跳轉
              window.open(`https://myntust.com/courses/${currentCode}`, '_blank');
            }
          });
        });
      };

      // 5. 建立 GPA 數值顯示標籤
      const display = document.createElement('div');
      display.className = 'gpa-display-val';
      display.id = `gpa-val-${currentCode}`; // ID 必須包含課號以利後續更新
      
      container.appendChild(btn);
      container.appendChild(display);

      // 6. 注入到表格最後一欄 (動作欄)
      const actionCell = row.cells[row.cells.length - 1];
      if (actionCell) {
        // 設定 CSS Flex 佈局讓 UI 更整齊
        actionCell.style.display = "flex";
        actionCell.style.flexDirection = "row";
        actionCell.style.alignItems = "center";
        actionCell.style.justifyContent = "center";
        
        // 放在該欄位最前面
        actionCell.prepend(container);
      }

      // 7. 注入後立即檢查快取，如果看過這門課就直接顯示數字
      updateDisplayFromCache(currentCode);
    }
  });
});

/**
 * 從 chrome.storage 讀取 GPA 快取並更新 UI
 * @param {string} code 課號
 * @param {object} providedCache 選填，若已拿到 cache 物件可直接傳入
 */
function updateDisplayFromCache(code, providedCache = null) {
  const updateUI = (cache) => {
    const val = cache[code];
    const el = document.getElementById(`gpa-val-${code}`);
    if (!val || !el) return;

    // 顯示標籤
    el.style.display = "block";
    el.classList.remove('gpa-high', 'gpa-medium', 'gpa-none');

    if (val === "無資訊" ||val === "請手動查詢") {
      el.innerText = val;
      el.classList.add('gpa-none');
    } else {
      const gpaNum = parseFloat(val);
      el.innerText = `GPA: ${val}`;
      if (gpaNum >= 3.7) el.classList.add('gpa-very-high');
      else if(gpaNum >= 3.3) el.classList.add('gpa-high');
      else if(gpaNum >= 3) el.classList.add('gpa-medium');
      else el.classList.add('gpa-low');
    }
  };

  if (providedCache) {
    updateUI(providedCache);
  } else {
    chrome.storage.local.get(['gpa_cache'], (res) => {
      if (res.gpa_cache) updateUI(res.gpa_cache);
    });
  }
}

/**
 * 監聽快取資料的變化
 * 當使用者在背景分頁查到資料後，這邊的 UI 會即時跳出數字
 */
chrome.storage.onChanged.addListener((changes) => {
  if (changes.gpa_cache) {
    const newCache = changes.gpa_cache.newValue;
    // 更新目前頁面上所有有快取紀錄的課程
    Object.keys(newCache).forEach(code => {
      updateDisplayFromCache(code, newCache);
    });
  }
});

// 開始監控台科大選課系統表格的動態變化
tableObserver.observe(document.body, { 
  childList: true, 
  subtree: true 
});

console.log("「台科大 GPA 查詢助手」已就緒，監控表格中...");