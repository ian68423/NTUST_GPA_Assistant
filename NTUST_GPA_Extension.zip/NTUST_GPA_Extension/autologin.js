if (typeof window.gpaAssistantInjected === 'undefined') {
  window.gpaAssistantInjected = true;
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  async function executeLogin() {
    const data = await new Promise(resolve => chrome.storage.local.get(['email', 'pw'], resolve));
    if (!data.email || !data.pw) return;

    let emailInput, pwInput, btn;
    for (let i = 0; i < 20; i++) {
      emailInput = document.querySelector('input[type="email"]');
      pwInput = document.querySelector('input[type="password"]');
      btn = document.querySelector('button[type="submit"]');
      if (emailInput && pwInput && btn) break;
      await sleep(500);
    }

    if (emailInput && pwInput && btn) {
      // 填寫帳號
      emailInput.focus();
      emailInput.value = data.email;
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(400);

      // 填寫密碼
      pwInput.focus();
      pwInput.value = data.pw;
      ['input', 'change', 'blur'].forEach(e => pwInput.dispatchEvent(new Event(e, { bubbles: true })));
      await sleep(600);

      // --- 執行登入 ---
      console.log("「GPA助手」：按下登入鈕...");
      btn.click();

      // --- 核心優化：按下後不等待，立即通知後台準備跳轉 ---
      // 給予 500ms 讓瀏覽器的 POST 請求發出，然後立即導向
      await sleep(500);
      chrome.runtime.sendMessage({ action: "fastForwardToCourse" });
    }
  }
  executeLogin();
}